# Distributor Pitch Deck

8-slide deck for distributor conversations (the user didn't provide an existing deck — this is built from the public distributor copy on dasexperten.biz and dasexperten.de/worldwide).

**Slides**
1. Title — headline + tagline
2. Big-stat opportunity
3. The old way (villain, on schwarz)
4. The fix (3 mechanisms)
5. Why distribute (4 reasons, margins / countries / growth / quality)
6. The range (5 product lines, wholesale pricing + MOQ)
7. Founding principle (quote, on rot)
8. Contact

Designed at 1920×1080. Keyboard nav: ←/→, PgUp/PgDn, R to reset.
